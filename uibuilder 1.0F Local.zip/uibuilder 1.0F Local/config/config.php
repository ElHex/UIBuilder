<?php
/*/
define('DB_HOST','contactek.com');
define('DB_USER','contactek_crm');
define('DB_PASS','Tele7607832');
define('DB_NAME','contactek_crm');
define('DB_PORT','3306');
define('DOMAIN',$_SERVER['HTTP_HOST'] ); // do not touch, this gets the domain name.
/*/

define('DB_HOST','contactekaws.cnm6fd8ueyds.us-east-1.rds.amazonaws.com');
define('DB_USER','elabarca');
define('DB_PASS','Tele7607832');
define('DB_NAME','contactek');
define('DB_PORT','3306');
?>